<?php

    include('header.php');
    include('topnav.php');
?>
  <div class="app-content content">
    <div class="content-wrapper">
      <div class="content-header row">
      </div>
      <div class="content-body">

        <section class="grid-with-label" id="grid-with-label">
          <div class="row">
            <div class="col-11">
              <div class="card">
                <div class="card-header">
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-3"></i></a>
                  <b><h4 class="card-title">Add Services</h4></b>
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                </div>
                <div class="card-content collapse show">
                  <div class="card-body">
                    <form action="http://localhost/beauty/bpms/addservicedb.php" method="POST">
                      <div class="form-body">
                      
                      <div class="col-md-6">
                          <div class="form-group">
                            <label for="service_type">Service type</label>
                            <select name="service_type" id="service_type">
                              <option value="hair">Hair </option>
                              <option value="skin">Skin </option>
                    </select>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Service</label>
                            <input type="text" name="service" required>   
                          </div>
                        </div>

                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Cost</label>
                            <input type="number" name="cost" required>   
                          </div>
                        </div>


                                          
                        
                       </tr>
                       <div class="form-actions">
                        <div class="text-left">
                          <button type="submit" class="btn btn-primary">Submit <i
                              class="ft-thumbs-up position-right"></i></button>
                          <button type="back"  class="btn btn-warning">Back <i
                              class="ft-refresh-cw position-right"></i></button>
                        </div>
                      </div>
                     </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
<?php
      include('footer.php');
?>