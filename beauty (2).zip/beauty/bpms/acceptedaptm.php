<?php

require 'config.php';

$a_id=$_GET['a_id'];

$sql="SELECT * FROM tbl_appointments where a_id='$a_id'";
    $records=mysqli_query($conn,$sql);
    while($tbl_appointments=mysqli_fetch_array($records))
    {
        $a_id=$tbl_appointments['a_id'];
        $username=$tbl_appointments['username'];
        $date=$tbl_appointments['date'];
        $time=$tbl_appointments['time'];
        $service_type=$tbl_appointments['service_type'];
        $service=$tbl_appointments['service'];
        $stylist_name=$tbl_appointments['stylist_name'];
       $email=$tbl_appointments['email'];
       $ph_no=$tbl_appointments['ph_no'];
    }
    
     $INSERT = "INSERT Into tbl_accepted(a_id,username,date,time,service_type,service,stylist_name,email,ph_no) values(?,?,?,?, ?,?,?,?,?)";
     //Prepare statement
    
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("isiissssi",$a_id, $username,$date,$time,$service_type,$service,$stylist_name,$email,$ph_no);
      $stmt->execute();
      echo '<script type="text/javascript"> alert(" Succesfully approved the appointment") </script>';
      header('Location: appointmentdtl.php');
     
     $stmt->close();
     $conn->close();
    

 die();



?>