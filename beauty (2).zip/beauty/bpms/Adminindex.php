<?php
    
    include('config.php');
    $sql="SELECT * FROM tbl_login";
    $records=mysqli_query($conn,$sql);

?>
  <?php 
  include('header.php');
  require 'adminmenu.php';
  require 'config.php';
  require 'topnav.php';
  ?>
  

  <div class="app-content content">
    <div class="content-wrapper"> 
      <div class="content-body">
      <section id="print">
          <div class="row">
            <div class="col-12">
              <div class="card" style="width:70rem;">
                <div class="card-header">
                  <h4 class="card-title">Customer List</h4>
                  <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>  
                  <div class="md-form mt-0">
                                  
                </div>
                <div class="card-content collapse show">
                  <div class="card-body card-dashboard">                      
                    <table class="table table-striped table-bordered dataex-visibility-print">
                      <thead>
                      <tr>
                          <th>User name</th>  
                          <th>Gender</th>                       
                          <th>Email</th>
                          <th>Phone number</th>
                        
                        </tr>
                      </thead>
                     <tbody>
                      <?php
                     
    while($tbl_login=mysqli_fetch_array($records))
    {
        echo'<tr>';
        echo'<td>'.$tbl_login['username'].'</td>';        
        echo'<td>'.$tbl_login['gender'].'</td>';
     
        echo'<td>'.$tbl_login['email'].'</td>';
        echo'<td>'.$tbl_login['phno'].'</td>';
      
        echo'</tr>';

    }
    ?>
              
            
                    </tfoot>
                    </table>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
  <?php
    include('footer.php');
    ?>