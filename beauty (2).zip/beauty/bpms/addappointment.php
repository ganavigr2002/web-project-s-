<?php

require 'config.php';

$username = $_POST['username'];
$gender = $_POST['gender'];
$date = $_POST['date'];
$time = $_POST['time'];
$service_type = $_POST['service_type'];
$service = $_POST['service'];
$ph_no = $_POST['ph_no'];
$email = $_POST['email'];
$stylist_name = $_POST['stylist_name'];

if (!empty($username) || !empty($gender)  || !empty($date)  || !empty($time)  || !empty($service) || !empty($service_type) || !empty($ph_no)  || !empty($email) || !empty($stylist_name)) {
    
     $SELECT = "SELECT email From tbl_appointments Where email = ? Limit 5";
     $INSERT = "INSERT Into tbl_appointments(username, gender, date, time, service_type,service,ph_no, email, stylist_name) values(?, ?, ?, ?,?, ?,?,?,?)";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $email);
     $stmt->execute();
     $stmt->bind_result($email);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ssiississ", $username, $gender,$date,$time,$service_type,$service, $ph_no,$email,$stylist_name);
      $stmt->execute();
      echo '<script type="text/javascript"> alert("You have succesfully took appointment") </script>';
   
     } else {
      echo '<script type="text/javascript"> alert("Someone already registered using this register number") </script>';
      header('Location: getappointment.php');
     }
     $stmt->close();
     $conn->close();
    }
    else {
 echo "All field are required";
 die();
}

?>
<?php
include('header.php');
    include('topnav.php');
    include('config.php');


    $username=$_POST['username'];
    $sql="SELECT * FROM tbl_appointments where username='$username'";
    $records=mysqli_query($conn,$sql);
    while($tbl_appointments=mysqli_fetch_array($records))
    {
       $username=$tbl_appointments['username'];
       $gender=$tbl_appointments['gender'];
       $date=$tbl_appointments['date'];
       $time=$tbl_appointments['time'];
       $service=$tbl_appointments['service'];
       $ph_no=$tbl_appointments['ph_no'];
       $email=$tbl_appointments['email'];
      
    }
?>
<script>
function goBack()
{
  window.history.back();
}
</script>

<div class="app-content content">
    <div class="content-wrapper">
      <div class="content-header tbl_company_profile">
      </div>
      <div class="content-body">

<section class="grid-with-label" id="grid-with-label">
          <div class="tbl_company_profile">
            <div class="col-8">
             <div class="card text-white bg-secondary">
              
                <div class="card-header bg-secondary text-white">
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                  <b><h4 class="card-title">Appointment  details</h4></b>
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                </div>
                </div>
                <div class="col-md-4">
                          <div class="form-group">
                            <label><b>NAME:</b></label>
                            <?php print("$username");?>
                            </div>
                </div>
                <div class="col-md-4">
                          <div class="form-group">
                            <label><b>Gender:</b></label>
                            <?php print("$gender");?>
                            </div>
                </div>
                <div class="col-md-4">
                          <div class="form-group">
                            <label><b>Date:</b></label>
                            <?php print("$date");?>
                            </div>
                </div>
                <div class="col-md-4">
                          <div class="form-group">
                            <label><b>Time:</b></label>
                            <?php print("$time");?>
                            </div>
                </div>

                <div class="col-md-4">
                          <div class="form-group">
                            <label><b>Service:</b></label>
                            <?php print("$service");?>
                            </div>
                </div>
                
                <div class="col-md-4">
                          <div class="form-group">
                            <label><b>EMAIL:</b></label>
                            <?php print("$email");?>
                            </div>
                </div>
                <div class="col-md-4">
                          <div class="form-group">
                            <label><b>PHONE:</b></label>
                            <?php print("$ph_no");?>
                            </div>
                </div>
              
                
                <div class="form-actions">
                        <div class="text-left">
                       

                              <a href="custdashboard.php" onclick="history.back(1);"><button type="submit" class="btn btn-warning">Back <i
                              class="ft-refresh-cw position-right"></i></button></a>
                              
                   
                   
                        </div>
            </div>`
          </div>
        </section>
      </div>
    </div>
  </div>
  <?php
    include('footer.php');
?>

