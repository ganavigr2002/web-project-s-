<?php

include "config.php";
if(isset($_POST['but_submit']))
{
    $username = mysqli_real_escape_string($conn,$_POST['txt_username']);
    $password = mysqli_real_escape_string($conn,$_POST['txt_pwd']);
    if ($username != "" && $password != "")
    {
        $sql_query = "select count(*) as cntUser from tbl_admin where username='".$username."' and password='".$password."'";
        $result = mysqli_query($conn,$sql_query);
        $row = mysqli_fetch_array($result);
        $count = $row['cntUser'];
        if($count > 0)
        {
          $_SESSION['username'] = $username;
            header('Location: Adminindex.php');
        }else
        {
          echo '<script type="text/javascript"> alert("Invalid login credentials") </script>';
        }

    }

}
?>
<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="Stack admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
  <meta name="keywords" content="admin template, stack admin template, dashboard template, flat admin template, responsive admin template, web app">
  <meta name="author" content="PIXINVENT">
  <title>Salon Management system</title>
  <link rel="shortcut icon" type="image/x-icon" href="app-assets/images/ico/favicon.ico">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i"
  rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="app-assets/css/vendors.css">
  <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/forms/icheck/icheck.css">
  <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/forms/icheck/custom.css">
  <link rel="stylesheet" type="text/css" href="app-assets/css/app.css">
  <link rel="stylesheet" type="text/css" href="app-assets/css/core/menu/menu-types/vertical-menu.css">
  <link rel="stylesheet" type="text/css" href="app-assets/css/pages/login-register.css">
  <link rel="stylesheet" type="text/css" href="../../../assets/css/style.css">
<script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=-pjjyd7dloA6s5MsKc558RqZ8VMDgHOFKly5jXs7-GsoG4tuuDRuhhI0OUGlypDKsJaA-WtPbManohL-o8rTVkg7hzrLj8BAu31yofu21w-QT953sLUNAXYgdgcrzxuUH44XwmLoJ4kk8YJeQCKkGJkV58omq6tHZ3Ms9YB97fAMWITXRANPHBfaCWu-F5U6bVL52-Hn5ODVRvKbMXeZEqSiOHnQxS4ieQypSPCZmUZLm9YgY9L-4Nd_OOSghPHKj9oiaVjqTZ2IxsETSkc9L3AMUvKFy53MKxzHaadDzDpPDN4GklRRucPNEAuI7cs9GPGTPCgpdgBp3x74VegpAYq-K79uVO1uxUhnL6joFYN3EnPlAwvnqOoxT9KhrWpIfZltX9ZNe-pe3xoK1QZP1gNw7EYiaRNTvnU0EUXtve4yIxX6MmBsjsB51BmKrf2BCVznOuq84_q0IWP3IvfmDqR1QUgisopYDjx5LtSaoIPxaMo1TBDTzAucz1q0ZiuoBQ8g4HS-5jGPYsKEi0EXfaWs8c23M4n0dlJi2YE9FHuQOqAufBnlmnYmuECp0I-K_97kWuowm_PwS_SLKWgfEYlvzxoobz8VCsX4peo8xUBWgg7ws_zjNPwFq9tB_3WCRJknMOpKQwIAs2zwnF_Fg-AtKnYvtTIGcnh9y96_UhdC_VANiYFc2uDLhir6CiJxjDYo5riue4w0qTlTWKpa-aCJZPNTsPyisKG86VzDWHz_f761zg_8Bs3PaGutWyAAPW7DbVlLMiIjc2PviHw_NEOc-V5wtJa9z_IxJgtMU7zzpoYZH9Wv6zc0pSAd0BNgr2rju5FA_03zg6T9PbMAhrlMoCcJa3jM1vanHWJIb0ogONjkrlV-tB2drRYtOZU3wBC4r-s4VdOkfH8Sgy4hHWTg1_D9fFSadli5REfaLx_ro4pp7im0HOAA0HHWEVHCpu7KlCJUD016ccEGb9WPyeH7hQdO--moMip3Ribou-if9VdPbbn-4goiqd9YZIjo3r8R7jQKxYJrwfn0MBt4buMZ_NemR_h5Ju3JkJuqv0lkoMI38N6Ey2e2P0mH6qbxp1uXkhXTWMXeLRNtcHTn3nxZ3cvUBB-HKGnIquA9T84l4B1SVWLKDVRg4DTdVlP5PE81PlsOBBUEXbX-57BjWCZCbrL_9vUTWS2xYJ3s1nLOQw5KvufeskGjpt_B9-rtw6DgRksp10MJ7cY1DXIZ2A" charset="UTF-8"></script></head>
<body class="vertical-layout vertical-menu 1-column   menu-expanded blank-page blank-page"
data-open="click" data-menu="vertical-menu" data-col="1-column">

  <div class="app-content content">
    <div class="content-wrapper">
      <div class="content-header row"></div>
      <div class="content-body">
        <section class="flexbox-container">
          <div class="col-12 d-flex align-items-center justify-content-center">
            <div class="col-md-4 col-10 box-shadow-2 p-0">
              <div class="card border-grey border-lighten-3 m-0">
                <div class="card-header border-0">
                  <div class="card-title text-center">
                    <div class="p-1">
                         <h2 class="brand-text">Salon Management System</h2>
                    </div>
                  </div>
                  <h6 class="card-subtitle line-on-side text-muted text-center font-small-6 pt-2">
                    <span>Admin Login</span>
                  </h6>
                </div>
                <div class="card-content">
                  <div class="card-body">
                         <form method="post" action="">
                         <fieldset class="form-group position-relative has-icon-left mb-0">
                         <input type="text" class="form-control form-control-lg" id="txt_username" name="txt_username" placeholder="Enter Username" />
                           <div class="form-control-position">
                          <i class="ft-user"></i>
                        </div>
                        </fieldset>
                        <fieldset class="form-group position-relative has-icon-left mb-0">
                         <input type="password" class="form-control form-control-lg" id="txt_username" name="txt_pwd" placeholder="Enter password" />
                           <div class="form-control-position">
                          <i class="fa fa-key"></i>
                        </div>
                        </fieldset>
                        <br><button type="submit" value="Login" class="btn btn-pink btn-lg btn-block"  name="but_submit" id="but_submit" />&nbsp;<i class="ft-unlock"></i>Login</button>
                       
                      </form>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </section>
</div>
</div>
</div>
<?php
 include "logintopnav.php"; 
  include "footer.php";
?>

