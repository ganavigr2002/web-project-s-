<?php

require 'config.php';

$service_type = $_POST['service_type'];
$service = $_POST['service'];
$cost = $_POST['cost'];


if (!empty($service_type) || !empty($service)  || !empty($cost)) {
    
     $SELECT = "SELECT service From tbl_service Where service = ? Limit 1";
     $INSERT = "INSERT Into tbl_service(service_type, service, cost) values(?, ?, ?)";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("i", $s_id);
     $stmt->execute();
     $stmt->bind_result($s_id);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ssi", $service_type, $service,$cost);
      $stmt->execute();
      echo '<script type="text/javascript"> alert("New service added successfully") </script>';
      header('Location: addservice.php');
     } else {
      echo '<script type="text/javascript"> alert("Service already exist") </script>';
   
     }
     $stmt->close();
     $conn->close();
    }
    else {
 echo "All field are required";
 die();
}

?>

      </div>
    </div>
  </div>
  <?php
    include('footer.php');
?>

