<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="main-menu-content">
      <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
        <li class=" navigation-header">
          <span>Menu</span><i class=" ft-minus" data-toggle="tooltip" data-placement="right"
          data-original-title="General"></i>
        </li>
        <div class="dropdown-divider"></div>   
        <li class=" nav-item"><a href="salon/frontpage.php"><i class="ft-home"></i><span class="menu-title" data-i18n="">Home</span></a>
        <div class="dropdown-divider"></div>

        <li class=" nav-item"><a href="#"><i class="ft-folder"></i><span class="menu-title" data-i18n="">Appointments</span></a>
          <ul class="menu-content">
            <li><a class="menu-item" href="appointmentdtl.php">All appointments</a>
              
            </li>
            <li><a class="menu-item" href="accepteddtl.php">Accepted</a>
            </li>
            </li>
            <li><a class="menu-item" href="rejecteddtl.php">Rejected</a>
            </li>
            </li>
            <li><a class="menu-item" href="completeddtl.php">Completed</a>
            </li>
          </ul>
        </li> 
        <div class="dropdown-divider"></div>   
        <li class=" nav-item"><a href="#"><i class="ft-list"></i><span class="menu-title" data-i18n="">Services</span></a>
          <ul class="menu-content">
            <li><a class="menu-item" href="addservice.php">Add services</a>
              
            </li>
            <li><a class="menu-item" href="viewservices.php">View services</a>
            </li>
          </ul>
        </li> 
        
        <div class="dropdown-divider"></div>   
        <li class=" nav-item"><a href="#"><i class="ft-list"></i><span class="menu-title" data-i18n="">Stylist</span></a>
          <ul class="menu-content">
            <li><a class="menu-item" href="addstylist.php">Add Stylists</a>
              
            </li>
            <li><a class="menu-item" href="viewstylist.php">View Stylist</a>
            </li>
          </ul>
        </li> 
        <div class="dropdown-divider"></div>   

        
	<li class=" nav-item"><a href="payment.php"><i class="ft-folder"></i><span class="menu-title" data-i18n="">Payment</span></a>
        </li> 
        <div class="dropdown-divider"></div>   
      
         <li class=" nav-item"><a href="#"><i class="ft-folder"></i><span class="menu-title" data-i18n="">Manage</span></a>
          <ul class="menu-content">
            <li><a class="menu-item" href="http://localhost/salon/fp.php">Logout</a></li>
        <div class="dropdown-divider"></div>
        
      </ul>
    </div>
  </div>