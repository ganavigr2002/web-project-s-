<?php

require 'config.php';

$username = $_POST['username'];
$gender = $_POST['gender'];
$phno = $_POST['phno'];
$email = $_POST['email'];
$password = $_POST['password'];

if (!empty($username) || !empty($gender)  || !empty($phno)  || !empty($email)   || !empty($password)) {
    
     $SELECT = "SELECT email From tbl_login Where email = ? Limit 1";
     $INSERT = "INSERT Into tbl_login(username, gender, phno, email, password) values(?, ?, ?, ?, ?)";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $email);
     $stmt->execute();
     $stmt->bind_result($email);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ssiss", $username, $gender, $phno,$email,$password);
      $stmt->execute();
      echo '<script type="text/javascript"> alert("New user added successfully") </script>';
      header("Location:custlogin.php");

     } else {
      echo '<script type="text/javascript"> alert("Someone already registered using this register number") </script>';
      header("Location:customerreg.php");
     }
     $stmt->close();
     $conn->close();
    }
    else {
 echo "All field are required";
 die();
}

?>

