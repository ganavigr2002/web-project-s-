<?php

include('config.php');
$std_name = $_POST['std_name'];
$std_clg_name = $_POST['std_clg_name'];
$std_branch= $_POST['std_branch'];
$std_regno = $_POST['std_regno'];
$std_sem= $_POST['std_sem'];
$std_gender= $_POST['std_gender'];
$std_email = $_POST['std_email'];
$std_phno= $_POST['std_phno'];
$std_percentage = $_POST['std_percentage'];


    

     $INSERT = "INSERT Into tbl_std_info (std_name,std_clg_name,std_branch,std_regno,std_sem,std_gender,std_email,std_phno,std_percentage) values(?,?, ?,?,?,?,?,?,?)";
     
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("sssiissii", $std_name,$std_clg_name, $std_branch,$std_regno,$std_sem,$std_gender,$std_email,$std_phno,$std_percentage);
      $stmt->execute();
     


    include('a.php');

?>