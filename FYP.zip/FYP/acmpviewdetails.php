<?php   
    include('header.php');
    include('topnav.php');
    include('config.php');
    $company_name=$_GET['company_name'];
    $sql="SELECT * FROM tbl_company_profile where company_name='$company_name'";
    $records=mysqli_query($conn,$sql);
    while($tbl_company_profile=mysqli_fetch_array($records))
{

    $company_image=$tbl_company_profile['company_image'];
   $company_name=$tbl_company_profile['company_name'];
   $company_address=$tbl_company_profile['company_address'];
   $company_domain=$tbl_company_profile['company_domain'];
   $company_number=$tbl_company_profile['company_number'];
   $company_email=$tbl_company_profile['company_email'];
   $company_vision=$tbl_company_profile['company_vision'];
   $company_mission=$tbl_company_profile['company_mission'];
   
  
}

?>
<script>
function goBack()
{
  window.history.back();
}
</script>

<div class="app-content content">
    <div class="content-wrapper">
      <div class="content-header tbl_company_profile">
      </div>
      <div class="content-body">

<section class="grid-with-label" id="grid-with-label">
          <div class="tbl_company_profile">
            <div class="col-9">
             <div class="card text-white bg-secondary">
              
                <div class="card-header bg-secondary text-white">
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                  <b><h4 class="card-title">Company details</h4></b>
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                </div>
                </div>
                
                <div class="col-md-6">
                          <div class="form-group">
                            <label><b>COMPANY NAME:</b></label>
                            <?php print("$company_name");?>
                            </div>
                </div>
                <div class="col-md-6">
                          <div class="form-group">
                            <label><b>COMPANY ADDRESS:</b></label>
                            <?php print("$company_address");?>
                            </div>
                </div>
                <div class="col-md-6">
                          <div class="form-group">
                            <label><b>COMPANY DOMAIN:</b></label>
                            <?php print("$company_domain");?>
                            </div>
                </div>
                <div class="col-md-4">
                          <div class="form-group">
                            <label><b>PHONE:</b></label>
                            <?php print("$company_number");?>
                            </div>
                </div>
                <div class="col-md-4">
                          <div class="form-group">
                            <label><b>EMAIL:</b></label>
                            <?php print("$company_email ");?>
                            </div>
                </div>
                <div class="col-md-6">
                          <div class="form-group">
                            <label><b>COMPANY VISSION:</b></label>
                            <?php print("$company_vision");?>
                            </div>
                </div>
                <div class="col-md-6">
                          <div class="form-group">
                            <label><b>COMPANY MISSION</b></label>
                            <?php print("$company_mission");?>
                            </div>
                </div>
                
                <div class="form-actions">
                        <div class="text-left">
                       
                          
                        &nbsp;<button onclick="goBack()"  class="btn btn-teal">&nbsp;Back <i
                              class="ft-refresh-cw position-right"></i></button>
                   
                        </div>
            </div>`
          </div>
        </section>
      </div>
    </div>
  </div>
  <?php
    include('footer.php');
?>

