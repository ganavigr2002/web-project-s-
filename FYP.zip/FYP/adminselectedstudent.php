<?php
    include('config.php');


    $sql="SELECT * FROM tbl_selected_std";
    $records=mysqli_query($conn,$sql);
    $sql="SELECT * FROM tbl_company_profile";
    $record=mysqli_query($conn,$sql);
    


?>
<?php
 include('header.php');
 include('topnav.php');
 ?>
 <script>
function goBack()
{
  window.history.back();
}
</script>

<div class="app-content content">
    <div class="content-wrapper">
      <div class="content-header tbl_company_profile">
      </div>
      <div class="content-body">

<section class="grid-with-label" id="grid-with-label">
          <div class="tbl_company_profile">
            <div class="col-9">
             <div class="card text-white bg-secondary">
              
             <div class="card-header bg-secondary text-white">
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                  <b><h4 class="card-title">Student details</h4></b>
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                </div>
                </div>
                 

                
                  <div class="card-content collapse show">
                                    <div class="tbl_company_profile">
                                        <div class="col-11">
                                            <div class="table-responsive">
                                                <table class="table table-bordepink">
                                                    <thead>
                                                        <tr>
                                                            <th>Student name</th>
                                                            <th>College name</th>
                                                            <th>Selected by</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>


                                                        <tr>
                                                            
<?php
   while($tbl_selected_std=mysqli_fetch_array($records))
   {
       echo'<tr>';
       echo'<td>'.$tbl_selected_std['std_name'].'</td>';    
       echo'<td>'.$tbl_selected_std['std_clg_name'].'</td>';  
       echo'<td>'.$tbl_selected_std['company_name'].'</td>';  
       echo'<td><a href=selectedstddetails.php?std_name='.$tbl_selected_std['std_name'].'&company_name='.$tbl_selected_std['company_name'].'><b>View details</b></a></td>';
   }


    
    
?>
</table>
<button onclick="goBack()"  class="btn btn-teal">&nbsp;Back <i
                              class="ft-refresh-cw position-right"></i></button>
                   
<br>


                  </div>
                </div>
              </div>
            </div>`
          </div>
        </section>
      </div>
    </div>
  </div>


 <?php
 include('footer.php');
 ?>