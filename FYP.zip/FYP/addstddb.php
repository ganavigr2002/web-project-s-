<?php

require 'config.php';
session_start();
$username=$_SESSION["username"];

$std_name = $_POST['std_name'];
$std_clg_name = $_POST['std_clg_name'];
$std_branch= $_POST['std_branch'];
$std_regno = $_POST['std_regno'];
$std_sem= $_POST['std_sem'];
$std_gender= $_POST['std_gender'];
$std_email = $_POST['std_email'];
$std_phno= $_POST['std_phno'];
$std_percentage = $_POST['std_percentage'];
$backlogs= $_POST['backlogs'];

if (!empty($std_name) || !empty($std_clg_name) || !empty($std_branch)  || !empty($std_regno) || !empty($std_sem)  || !empty($std_gender) || !empty($email) || !empty($std_phno)  || !empty($std_percentage)) {   
     $SELECT = "SELECT std_regno From tbl_std_info Where std_regno = ? Limit 1";
     $INSERT = "INSERT Into tbl_std_info (std_name,std_clg_name,std_branch,std_regno,std_sem,std_gender,std_email,std_phno,std_percentage,backlogs) values(?,?, ?,?,?,?,?,?,?,?)";
     
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $std_regno);
     $stmt->execute();
     $stmt->bind_result($std_regno);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ssssissiii", $std_name,$std_clg_name, $std_branch,$std_regno,$std_sem,$std_gender,$std_email,$std_phno,$std_percentage,$backlogs);
      $stmt->execute();
      echo '<script type="text/javascript"> alert("Details updated successfully") </script>';
     } else {
        echo '<script type="text/javascript"> alert("Someone already register using this register number") </script>';
            include("addstd.php");
     }
     $stmt->close();
     $conn->close();
    }
    else {
 echo "All field are required";
 die();
}


include('header.php');
include('topnav.php');
include('config.php');

$sql="SELECT * FROM tbl_selected_std where std_name='$std_name'";
$records=mysqli_query($conn,$sql);
while($tbl_selected_std=mysqli_fetch_array($records))
{


$std_name=$tbl_selected_std['std_name'];
$std_clg_name = $tbl_selected_std['std_clg_name'];
$std_branch=$tbl_selected_std['std_branch'];
$std_regno=$tbl_selected_std['std_regno'];
$std_sem=$tbl_selected_std['std_sem'];
$std_email=$tbl_selected_std['std_email'];
$std_gender=$tbl_selected_std['std_gender'];
$std_phno=$tbl_selected_std['std_phno'];
$std_percentage=$tbl_selected_std['std_percentage'];
$backlogs=$tbl_selected_std['backlogs'];
$company_name=$tbl_selected_std['company_name'];

}

?>
<script>
function goBack()
{
window.history.back();
}
</script>

<div class="app-content content">
<div class="content-wrapper">
  <div class="content-header tbl_company_profile">
  </div>
  <div class="content-body">

<section class="grid-with-label" id="grid-with-label">
      <div class="tbl_company_profile">
        <div class="col-9">
         <div class="card text-white bg-secondary">
          
            <div class="card-header bg-secondary text-white">
              <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
              <b><h4 class="card-title">Student details</h4></b>
              <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
            </div>
            </div>
            <div class="col-md-4">
                      <div class="form-group">
                        <label><b>NAME:</b></label>
                        <?php print("$std_name");?>
                        </div>
            </div>
            <div class="col-md-4">
                      <div class="form-group">
                        <label><b>COLLEGE NAME:</b></label>
                        <?php print("$std_clg_name");?>
                        </div>
            </div>
            <div class="col-md-4">
                      <div class="form-group">
                        <label><b>BRANCH:</b></label>
                        <?php print("$std_branch");?>
                        </div>
            </div>
            <div class="col-md-4">
                      <div class="form-group">
                        <label><b>SEM:</b></label>
                        <?php print("$std_sem");?>
                        </div>
            </div>
            <div class="col-md-4">
                      <div class="form-group">
                        <label><b>REGNO:</b></label>
                        <?php print("$std_regno");?>
                        </div>
            </div>
            <div class="col-md-4">
                      <div class="form-group">
                        <label><b>EMAIL:</b></label>
                        <?php print("$std_email");?>
                        </div>
            </div>
            <div class="col-md-4">
                      <div class="form-group">
                        <label><b>PHONE:</b></label>
                        <?php print("$std_phno");?>
                        </div>
            </div>
            <div class="col-md-4">
                      <div class="form-group">
                        <label><b>PERCENTAGE:</b></label>
                        <?php print("$std_percentage");?>
                        </div>
            </div>
            <div class="col-md-4">
                      <div class="form-group">
                        <label><b>BACKLOGS:</b></label>
                        <?php print("$backlogs");?>
                        </div>
            </div>
           
            <div class="form-actions">
                    <div class="text-left">
                   
                      
                    <a href="addstd.php" onclick="history.back(1);"><button type="submit" class="btn btn-warning">Back <i
                       class="ft-refresh-cw position-right"></i></button></a>
            
               
                    </div>
        </div>
      </div>
    </section>
  </div>
</div>
</div>
<?php
include('footer.php');
?>



