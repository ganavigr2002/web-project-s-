<?php
    
    include('config.php');
    $sql="SELECT * FROM tbl_login";
    $records=mysqli_query($conn,$sql);
    $sql="SELECT * FROM tbl_login_admin ";
    $records1=mysqli_query($conn,$sql);
    $sql="SELECT * FROM tbl_login_officer";
    $record=mysqli_query($conn,$sql);
?>
  <?php 
  include('header.php');
  require 'menu.php';
  require 'config.php';
  require 'topnav.php';
  ?>
  

  <div class="app-content content">
    <div class="content-wrapper"> 
      <div class="content-body">
      <section id="print">
          <div class="row">
            <div class="col-12">
              <div class="card" style="width:70rem;">
                <div class="card-header">
                  <h4 class="card-title">User List</h4>
                  <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>  
                  <div class="md-form mt-0">
                                  
                </div>
                <div class="card-content collapse show">
                  <div class="card-body card-dashboard">                      
                    <table class="table table-striped table-bordered dataex-visibility-print">
                      <thead>
                      <tr>
                          <th>User name</th>  
                          <th>Gender</th>                       
                          <th>Designation</th>
                          <th>Email</th>
                          <th>Phone number</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                     <tbody>
                      <?php
                       while($tbl_login_admin=mysqli_fetch_array($records1))
                       {
                   
                   
                          $username=$tbl_login_admin['username'];
                       }
    while($tbl_login=mysqli_fetch_array($records))
    {
        echo'<tr>';
        echo'<td>'.$tbl_login['username'].'</td>';        
        echo'<td>'.$tbl_login['gender'].'</td>';
        echo'<td>'.$tbl_login['designation'].'</td>';
        echo'<td>'.$tbl_login['email'].'</td>';
        echo'<td>'.$tbl_login['phonenumber'].'</td>';
        echo'<td><a href=admineditdata.php?email='.$tbl_login['email'].'><img src="app-assets/images/edit.png"/></a>&nbsp;|&nbsp;<a href=admindeletedata.php?email='.$tbl_login['email'].'><img src="app-assets/images/delete.png"/></td>';
        echo'</tr>';

    }
  
    while($tbl_login_officer=mysqli_fetch_array($record))
    {
        echo'<tr>';
        echo'<td>'.$tbl_login_officer['username'].'</td>';        
        echo'<td>'.$tbl_login_officer['gender'].'</td>';
        echo'<td>'.$tbl_login_officer['designation'].'</td>';
        echo'<td>'.$tbl_login_officer['email'].'</td>';
        echo'<td>'.$tbl_login_officer['phonenumber'].'</td>';
        echo'<td><a href=admineditdataofficer.php?email='.$tbl_login_officer['email'].'><img src="app-assets/images/edit.png"/></a>&nbsp;|&nbsp;<a href=admindeletedata.php?email='.$tbl_login_officer['email'].'><img src="app-assets/images/delete.png"/></td>';
        echo'</tr>';

    }
?>
            
                    </tfoot>
                    </table>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
  <?php
    include('footer.php');
    ?>