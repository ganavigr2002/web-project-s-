<?php
    include('config.php');
    $sql="SELECT * FROM tbl_std_info";
    $records=mysqli_query($conn,$sql);


?>
<?php
include('header.php');
include('topnav.php');
?>
<br><br>

        <div class="row match-height">
          <div class="col-xl-8 col-lg-10">
            <div class="card" style="width:30rem;height:60rem;left:1rem;">
              <div class="card-header border-0-bottom">
                <h4 class="card-title">Add student details </h4>
                <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>                
              </div>
              <div class="card-content collapse show">
                  <div class="card-body">
			        
                     
            <form action="http://localhost/fyp/addstudentdb.php" method="POST">
              
                      
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>Name</label>
                          <input type="text" name="std_name" required>
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                          <label>College Name</label>
                          <input type="text" name="std_clg_name" required>
                        </div>
                      </div>
           
                     
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>Branch</label>
                          <input type="text" name="std_branch" required>
                        </div>
                      </div>
                      
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>Regno</label>
                          <input type="text" name="std_regno" unique>
                        </div>
                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>sem</label>
                          <input type="text" name="std_sem" required>
                        </div>
                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>Gender</label>
                          <input type="text" name="std_gender" required>
                        </div>
                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>Email</label>
                          <input type="text" name="std_email" required>
                        </div>
                      </div>
                      <div class="col-md-10">
                        <div class="form-group">
                          <label>Phone number</label>
                                        <input type="text" name="std_phno" required>
                        </div>
                      </div>
                      <div class="col-md-10">
                        <div class="form-group">
                          <label>Percentage</label>
                          <input type="text" name="std_percentage" required>     
                        </div>
                      </div>
           
                      
                        
                          <button type="submit" class="btn btn-primary">Submit <i
                              class="ft-thumbs-up position-right"></i></button>
                          <button type="reset" class="btn btn-warning">Reset <i
                              class="ft-refresh-cw position-right"></i></button>
                      

</form>
</div>
</div>
                    
                    
              </div>
            </div>
        
              
            <div class="col-xl-4 col-sl-5">
            <div class="card" style="right:29rem;width:60rem;">
              <div class="card-content collapse show">
                <div class="card-body">
                  <h5><font size="+3">Details</font></h5>
                </div>
                <div class="text-center">
                <table border="2">
              <thead>
                              <tr>
                                <th>Name</th>
                                <th>College Name</th>
                                <th>Branch</th>
                                <th>Regno</th>
                                <th>Sem</th>
                                <th>Email</th>
                                <th>Email</th>
                                <th>Phone number</th>
                                <th>Percentage</th>
                                <th>Action</th>
                              </tr>
                            </thead>
<?php
    while($tbl_std_info=mysqli_fetch_array($records))
    {
        echo'<tr>';
        echo'<td>'.$tbl_std_info['std_name'].'</td>';
        echo'<td>'.$tbl_std_info['std_clg_name'].'</td>';
        echo'<td>'.$tbl_std_info['std_branch'].'</td>';
        echo'<td>'.$tbl_std_info['std_regno'].'</td>';
        echo'<td>'.$tbl_std_info['std_sem'].'</td>';
        echo'<td>'.$tbl_std_info['std_gender'].'</td>';
        echo'<td>'.$tbl_std_info['std_email'].'</td>';
        echo'<td>'.$tbl_std_info['std_phno'].'</td>';
        echo'<td>'.$tbl_std_info['std_percentage'].'</td>';
        echo'<td><a href=deletedata.php?regno='.$tbl_std_info['std_regno'].'>Delete</a></td>';
        echo'<td><a href=editdata.php?regno='.$tbl_std_info['std_regno'].'>Edit</a></td>';
        echo'</tr>';

    }
?>
</table>
</div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row match-height">
          <div class="col-xl-2 col-lg-2">
            <div class="card" style="width:30rem;height:60rem;left:1rem;">
              <div class="card-header border-0-bottom">
              <div class="container">
                <?php
                    include ('excel.php');
                  ?>
                </div>
                </div>
                </div>
                </div>
                </div>

<?php
    include('footer.php');
  ?>