<?php
$username = $_GET['username'];
$college_name = $_GET['college_name'];
$email = $_GET['email'];
$gender = $_GET['gender'];
$designation = $_GET['designation'];
$phonenumber= $_GET['phonenumber'];
$pwd= $_GET['pwd'];

include("config.php");
        $sql="UPDATE tbl_login_officer SET username='$username',pwd='$pwd',college_name='$college_name',gender='$gender',designation='$designation',phonenumber='$phonenumber',email='$email' WHERE email='$email'";
       if (mysqli_query($conn,$sql))
       {

         echo '<script type="text/javascript"> alert("Details updated successfully") </script>';
       
       }
       else
       {
        echo '<script type="text/javascript"> alert("Details not updated") </script>';
        include"admineditdataofficer.php";
       }

       include('header.php');
       include('topnav.php');
       include('config.php');
   
   
       
       $sql="SELECT * FROM tbl_login_officer where username='$username'";
       $records=mysqli_query($conn,$sql);
       while($tbl_login_officer=mysqli_fetch_array($records))
       {
          $username=$tbl_login_officer['username'];
          $college_name=$tbl_login_officer['college_name'];
          $gender=$tbl_login_officer['gender'];
          $designation=$tbl_login_officer['designation'];
          $phonenumber=$tbl_login_officer['phonenumber'];
          $email=$tbl_login_officer['email'];
          $pwd=$tbl_login_officer['pwd'];
       }
   ?>
   <script>
   function goBack()
   {
     window.history.back();
   }
   </script>
   
   <div class="app-content content">
       <div class="content-wrapper">
         <div class="content-header tbl_company_profile">
         </div>
         <div class="content-body">
   
   <section class="grid-with-label" id="grid-with-label">
             <div class="tbl_company_profile">
               <div class="col-8">
                <div class="card text-white bg-secondary">
                 
                   <div class="card-header bg-secondary text-white">
                     <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                     <b><h4 class="card-titble">User  details</h4></b>
                     <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                   </div>
                   </div>
                   <div class="col-md-4">
                             <div class="form-group">
                               <label><b>NAME:</b></label>
                               <?php print("$username");?>
                               </div>
                   </div>
                   <div class="col-md-4">
                             <div class="form-group">
                               <label><b>COMPANY NAME:</b></label>
                               <?php print("$college_name");?>
                               </div>
                   </div>
                   <div class="col-md-4">
                             <div class="form-group">
                               <label><b>GENDER:</b></label>
                               <?php print("$gender");?>
                               </div>
                   </div>
                   <div class="col-md-4">
                             <div class="form-group">
                               <label><b>DESIGNATION:</b></label>
                               <?php print("$designation");?>
                               </div>
                   </div>
                   
                   <div class="col-md-4">
                             <div class="form-group">
                               <label><b>EMAIL:</b></label>
                               <?php print("$email");?>
                               </div>
                   </div>
                   <div class="col-md-4">
                             <div class="form-group">
                               <label><b>PHONE:</b></label>
                               <?php print("$phonenumber");?>
                               </div>
                   </div>
                   <div class="col-md-4">
                             <div class="form-group">
                               <label><b>PASSWORD:</b></label>
                               <?php print("$pwd");?>
                               </div>
                   </div>
                   
                   
                   
                   <div class="form-actions">
                           <div class="text-left">
                          
                          <a href="http://www.gmail.com"> <button type="submit" class="btn btn-primary">Send mail <i
                                 class="ft-thumbs-up position-right"></i></button></a>
                             
                                 <a href="adminindex.php" onclick="history.back(1);"><button type="submit" class="btn btn-warning">Back <i
                                 class="ft-refresh-cw position-right"></i></button></a>
                      
                           </div>
               </div>
             </div>
           </section>
         </div>
       </div>
     </div>
     <?php
       include('footer.php');
   ?>
   
   
     
    

   

?>