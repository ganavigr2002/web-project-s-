<?php
    include('config.php');
    
    
    $sql="SELECT * FROM tbl_company_profile ";
    $records=mysqli_query($conn,$sql);
    
  
?>
<?php
 include('header.php');
 include('topnav.php');
 ?>
 <script>
function goBack()
{
  window.history.back();
}
</script>

<div class="app-content content">
    <div class="content-wrapper">
      <div class="content-header tbl_company_profile">
      </div>
      <div class="content-body">

<section class="grid-with-label" id="grid-with-label">
          <div class="tbl_company_profile">
            <div class="col-9">
             <div class="card text-white bg-secondary">
              
                <div class="card-header bg-secondary text-white">
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                  <b><h4 class="card-title">Company profile</h4></b>
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                </div>
                </div>
                 

                
                  <div class="card-content collapse show">
                                    <div class="tbl_company_profile">
                                        <div class="col-11">
                                            <div class="table-responsive">
                                                <table class="table table-bordepink">
                                                    <thead>
                                                        <tr>
                                                            <th>Company logo</th>
                                                            <th>Company name</th> 
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>


                                                        <tr>
                                                            
<?php
    while($tbl_company_profile = mysqli_fetch_array($records))
    {
        ?>
        <tr>
        
        
            <td><?php echo '<img src="data:image;base64,'.base64_encode($tbl_company_profile['company_image']).'" alt="Image" style="width: 100px;height: 100px" >';?> </td>
            <td> <br><b><?php echo $tbl_company_profile['company_name']?></b><br><br><b><?php echo $tbl_company_profile['company_address']?></b></td>

          <?php  echo'<td><a href=acmpviewdetails.php?company_name='.$tbl_company_profile['company_name'].'><b><br>View details</b></a></td>';
            ?>
           </td>
           </tr>

        <?php
    }
    
    
?>
</table>

<button onclick="goBack()"  class="btn btn-teal">&nbsp;Back <i
                              class="ft-refresh-cw position-right"></i></button>
                  </div>
                </div>
              </div>
            </div>`
          </div>
        </section>
      </div>
    </div>
  </div>


 <?php
 include('footer.php');
 ?>