<?php

require 'config.php';

$std_name = $_POST['std_name'];
$std_clg_name = $_POST['std_clg_name'];
$std_branch= $_POST['std_branch'];
$std_regno = $_POST['std_regno'];
$std_sem= $_POST['std_sem'];
$std_gender= $_POST['std_gender'];
$std_email = $_POST['std_email'];
$std_phno= $_POST['std_phno'];
$std_percentage = $_POST['std_percentage'];


if (!empty($std_name) || !empty($std_clg_name) || !empty($std_branch)  || !empty($std_regno) || !empty($std_sem)  || !empty($std_gender) || !empty($email) || !empty($std_phno)  || !empty($std_percentage)) {   
     $SELECT = "SELECT std_email From tbl_std_info Where std_email = ? Limit 1";
     $INSERT = "INSERT Into tbl_std_info (std_name,std_clg_name,std_branch,std_regno,std_sem,std_gender,std_email,std_phno,std_percentage) values(?,?, ?,?,?,?,?,?,?)";
     
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $std_email);
     $stmt->execute();
     $stmt->bind_result($std_email);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("sssiissii", $std_name,$std_clg_name, $std_branch,$std_regno,$std_sem,$std_gender,$std_email,$std_phno,$std_percentage);
      $stmt->execute();
      echo "New record inserted sucessfully";
     } else {
      echo "Someone already register using this email";
     }
     $stmt->close();
     $conn->close();
    }
    else {
 echo "All field are required";
 die();
}


      include('addstudentsjpec.php');

?>

