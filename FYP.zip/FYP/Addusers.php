<?php

    include('header.php');
    include('topnav.php');
?>
<script>
function goBack()
{
  window.history.back();
}
</script>
  <div class="app-content content">
    <div class="content-wrapper">
      <div class="content-header row">
      </div>
      <div class="content-body">

        <section class="grid-with-label" id="grid-with-label">
          <div class="row">
            <div class="col-11">
              <div class="card">
                <div class="card-header">
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-3"></i></a>
                  <b><h4 class="card-title">Add colleges</h4></b>
                  <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
                </div>
                <div class="card-content collapse show">
                  <div class="card-body">
                    <form action="http://localhost/fyp/addusersdb.php" method="POST">
                      <div class="form-body">
                      
                        <div class="col-md-4">
                          <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="username" required>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Company Name</label>
                            <input type="text" name="company_name" required>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Gender</label>
                            <input type="text" name="gender" required>
                            
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Designation</label>
                            <input type="text" name="designation" required>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Phone number</label>
                            <input type="text" name="email" required>
                          </div>
                        </div>

                        <div class="col-md-10">
                          <div class="form-group">
                            <label>Email</label>
                            <input type="text" name="phonenumber" required>
                          </div>
                        </div>

                        <div class="col-md-4">
                          <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" required>
                          </div>
                        </div>

                        
                                          
                        
                       </tr>
                       <div class="form-actions">
                        <div class="text-left">
                          <button type="submit" class="btn btn-primary">Submit <i
                              class="ft-thumbs-up position-right"></i></button>
                          
                          <button onclick="goBack()"  class="btn btn-warning">Back <i
                              class="ft-refresh-cw position-right"></i></button>
                   
                        </div>
                      </div>
                     </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
<?php
      include('footer.php');
?>