<?php

$email = $_GET['email'];



include("config.php");
    
    
        $sql="DELETE FROM tbl_login_officer   WHERE email='$email'";
       if (mysqli_query($conn,$sql))
       {
          echo " Record deleted Successfully";
          header("Location:Adminindex.php");
          

       }
       else
       {
          echo "Record not updated";
   
       }
       $sql="DELETE FROM tbl_login   WHERE email='$email'";
       if (mysqli_query($conn,$sql))
       {
          echo " Record deleted Successfully";
          header("Location:Adminindex.php");
          

       }
       else
       {
          echo "Record not updated";
   
       }
      
   

?>