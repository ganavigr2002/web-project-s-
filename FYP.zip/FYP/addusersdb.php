<?php

require 'config.php';

$username = $_POST['username'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$phno = $_POST['phno'];
$password = $_POST['password'];
$clg_name = $_POST['clg_name'];
if (!empty($username) || !empty($gender)  || !empty($email) || !empty($phonenumber)  || !empty($password) || !empty($clg_name)) {
    
     $SELECT = "SELECT email From tbl_login_student Where email = ? Limit 1";
     $INSERT = "INSERT Into tbl_login_student (username, gender,  email, phno, password,clg_name) values(?, ?, ?, ?, ?, ?)";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $email);
     $stmt->execute();
     $stmt->bind_result($email);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum==0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("sssiss", $username, $gender,$email, $phno,$password,$clg_name);
      $stmt->execute();
      echo '<script type="text/javascript"> alert("New user added successfully") </script>';
            include('studentlogin.php');
     } else {
      echo '<script type="text/javascript"> alert("Someone already registered using this register number") </script>';
      header("Location:studentreg.php");
     }
     $stmt->close();
     $conn->close();
    }
    else {
 echo "All field are required";
 die();
}

?>

