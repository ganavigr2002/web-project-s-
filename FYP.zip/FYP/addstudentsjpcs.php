<?php
    include('config.php');
    session_start();
    $username=$_SESSION["username"];
    include "config.php";
    $sql="SELECT * FROM tbl_login where username='$username' ";
    $record=mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Stack admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, stack admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>Card Actions - Stack Responsive Bootstrap 4 Admin Template</title>
    <link rel="apple-touch-icon" href="../../../app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="../../../app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="../../../app-assets/vendors/css/vendors.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/colors.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/components.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/core/colors/palette-gradient.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="../../../assets/css/style.css">
    <!-- END: Custom CSS-->

</head>

    <div class="app-content content">
        <div class="content-wrapper">
            
            <div class="content-body">
                <!-- card actions section start -->
                <section id="card-actions">
                    <div class="row">
                        <div class="col-14">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Add student details</h4>
                                    <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="ft-user"></i></a></li>
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-content collapse show">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-sm-2 col-sm-4 mb-2">
                                            <div class="card-content collapse show">
                  <div class="card-body">
			        <p><a href="excel.php"><b>CLICK HERE</b> </a>TO ADD EXCEL SHEET</p></br>
                     
            <form action="http://localhost/fyp/addstudentdbsjpcs.php" method="POST">
              
                      
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>Name</label>
                          <input type="text" name="std_name" required>
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                          <label>College Name</label>
                          <input type="text" name="std_clg_name" required>
                        </div>
                      </div>
           
                     
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>Branch</label>
                          <input type="text" name="std_branch" required>
                        </div>
                      </div>
                      
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>Regno</label>
                          <input type="text" name="std_regno" unique>
                        </div>
                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>Sem</label>
                          <input type="text" name="std_sem" required>
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                          <label>Gender</label>
                          <input type="text" name="std_gender" required>
                        </div>
                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                          <label>Email</label>
                          <input type="text" name="std_email" required>
                        </div>
                      </div>
                      <div class="col-md-10">
                        <div class="form-group">
                          <label>Phone number</label>
                              <input type="text" name="std_phno" required>
                        </div>
                      </div>
                      <div class="col-md-10">
                        <div class="form-group">
                          <label>Percentage</label>
                          <input type="text" name="std_percentage" required>     
                        </div>
                      </div>
           
                      
                        
                          <button type="submit" class="btn btn-primary">Submit <i
                              class="ft-thumbs-up position-right"></i></button>
                          <button type="reset" class="btn btn-warning">Reset <i
                              class="ft-refresh-cw position-right"></i></button>
                      

</form>
</div>
</div>
       
                                            </div>
                                            <div class="col-xl-6 col-lg-6 mb-2">
                                            <div class="table-responsive">
                                                    <table class="table table-striped table-bordered dataex-visibility-print">
                                                        <thead>
                                                                        <tr>
                                                                          <th>Name</th>
                                                                          <th>College Name</th>
                                                                          <th>Branch</th>
                                                                          <th>Regno</th>
                                                                          <th>Sem</th>
                                                                          <th>Email</th>
                                                                          <th>Email</th>
                                                                          <th>Phone number</th>
                                                                          <th>Percentage</th>
                                                                          <th>Action</th>
                                                                        </tr>
                                                                      </thead>
                                          <?php
                                          while($tbl_login=mysqli_fetch_array($record))
                                          {
                                            $username=$tbl_login['username'];
                                            $college_name=$tbl_login['college_name'];
                                          }
                                          $sql="SELECT * FROM tbl_std_info where std_clg_name='$college_name' ";
                                          $records=mysqli_query($conn,$sql);
                                              while($tbl_std_info=mysqli_fetch_array($records))
                                              {
                                                  echo'<tr>';
                                                  echo'<td>'.$tbl_std_info['std_name'].'</td>';
                                                  echo'<td>'.$tbl_std_info['std_clg_name'].'</td>';
                                                  echo'<td>'.$tbl_std_info['std_branch'].'</td>';
                                                  echo'<td>'.$tbl_std_info['std_regno'].'</td>';
                                                  echo'<td>'.$tbl_std_info['std_sem'].'</td>';
                                                  echo'<td>'.$tbl_std_info['std_gender'].'</td>';
                                                  echo'<td>'.$tbl_std_info['std_email'].'</td>';
                                                  echo'<td>'.$tbl_std_info['std_phno'].'</td>';
                                                  echo'<td>'.$tbl_std_info['std_percentage'].'</td>';
                                                  echo'<td><a href=editdata.php?std_email='.$tbl_std_info['std_email'].'><img src="app-assets/images/edit.png"/></a> |&nbsp;<a href=deletedata.php?std_email='.$tbl_std_info['std_email'].'><img src="app-assets/images/delete.png"/></td>';
                                                  echo'</tr>';
                                          
                                              }
                                          ?>
                                          </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                   
                 
                        
                    </div>
                </section>
                <!-- // card-actions section end -->
            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light navbar-border">
        <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">Copyright &copy; 2019 <a class="text-bold-800 grey darken-2" href="https://themeforest.net/user/pixinvent/portfolio?ref=pixinvent" target="_blank">PIXINVENT </a></span><span class="float-md-right d-none d-lg-block">Hand-crafted & Made with <i class="ft-heart pink"></i></span></p>
    </footer>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="../../../app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="../../../app-assets/js/core/app-menu.js"></script>
    <script src="../../../app-assets/js/core/app.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <!-- END: Page JS-->

</body>
<!-- END: Body-->

</html>