<?php
    
    $email=$_GET['email'];
    include("config.php");
    $sql="SELECT * FROM tbl_login_officer where email='$email'";
    $records=mysqli_query($conn,$sql);
    while($tbl_login_officer=mysqli_fetch_array($records))
    {
       $username=$tbl_login_officer['username'];
       $college_name=$tbl_login_officer['college_name'];
       $gender=$tbl_login_officer['gender'];
       $designation=$tbl_login_officer['designation'];
       $phonenumber=$tbl_login_officer['phonenumber'];
       $email=$tbl_login_officer['email'];
       $pwd=$tbl_login_officer['pwd'];
    }
   
?>
<?php

include('header.php');
include('topnav.php');
?>
<div class="app-content content">
<div class="content-wrapper">
  <div class="content-header row">
  </div>
  <div class="content-body">

    <section class="grid-with-label" id="grid-with-label">
      <div class="row">
        <div class="col-11">
          <div class="card">
            <div class="card-header">
              <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-3"></i></a>
              <b><h4 class="card-title">Edit details</h4></b>
              <a class="heading-elements-toggle"><i class="ft-align-justify font-medium-5"></i></a>
            </div>
            <div class="card-content collapse show">
              <div class="card-body">
              <form action="http://localhost/fyp/adminupdateofficer.php" method="GET">
                  <div class="form-body">
                  
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="username" value='<?php echo $username;?>'><br>
                      </div>
                    </div>
                      <div class="col-md-6">
                      <div class="form-group">
                        <label>College Name</label>
                        <input type="text" name="college_name" value='<?php echo $college_name;?>'><br>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Gender</label>
                        <input type="text" name="gender" value='<?php echo $gender;?>'><br>        
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Designation</label>
                        <input type="text" name="designation" value='<?php echo $designation;?>'><br>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Phone number</label>
                        <input type="text" name="phonenumber" value='<?php echo $phonenumber;?>'><br>
                      </div>
                    </div>

                    <div class="col-md-10">
                      <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value='<?php echo $email;?>'><br>
                      </div>
                    </div>

                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Password</label>
                        <input type="text" name="pwd" value='<?php echo $pwd;?>'><br>
                      </div>
                    </div>
                   <div class="form-actions">
                    <div class="text-left">
                      <button type="submit" class="btn btn-primary">Update<i
                          class="ft-thumbs-up position-right"></i></button>
                      <button type="reset"  class="btn btn-warning">Reset<i
                          class="ft-refresh-cw position-right"></i></button>
                    </div>
                  </div>
                 </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
</div>
<?php
  include('footer.php');
?>
