<?php
    include('config.php');
    session_start();
    $username=$_SESSION["username"];
    include "config.php";
    $sql="SELECT * FROM tbl_login_officer where username='$username' ";
    $record=mysqli_query($conn,$sql);
    while($tbl_login_officer=mysqli_fetch_array($record))
    {
      $username=$tbl_login_officer['username'];
      $college_name=$tbl_login_officer['college_name'];
    }
?>
<?php
include('header.php');
include('topnav.php');
?>
<script>
function goBack()
{
  window.history.back();
}
</script>


    <div class="app-content content">
        <div class="content-wrapper">
            
            <div class="content-body">
                <!-- card actions section start -->
                <section id="card-actions">
                    <div class="row">
                        <div class="col-sm-9">
                            <div class="card" style="18rem";>
                                <div class="card-header">
                                    <h4 class="card-title">Add student details</h4>
                                    <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="ft-user"></i></a></li>
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-content collapse show">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-sm-6 col-sm-4 mb-2">
                                            <div class="card-content collapse show">
                  <div class="card-body">
			        <p><a href="excel.php"><b>CLICK HERE</b> </a>TO ADD EXCEL SHEET</p></br>
                     
            <form action="http://localhost/fyp/addstddb.php" method="POST">
              
                      
                      <div class="col-md-18">
                        <div class="form-group">
                          <label>Name</label>
                          <input type="text" name="std_name" required>
                        </div>
                      </div>
                      <div class="col-md-18">
                        <div class="form-group">
                          <label>College Name</label>
                          <input type="text" name="std_clg_name" value='<?php echo $college_name;?>' required>
                        </div>
                      </div>
           
                     
                      <div class="col-md-18">
                        <div class="form-group">
                          <label>Branch</label>
                          <input type="text" name="std_branch" required>
                        </div>
                      </div>
                      
                      <div class="col-md-18">
                        <div class="form-group">
                          <label>Regno</label>
                      
                          <input type="text" name="std_regno" unique>
                        </div>
                      </div>
                      <div class="col-md-18">
                        <div class="form-group">
                          <label>Sem</label>
                          <input type="text" name="std_sem" required>
                        </div>
                      </div>
                      <div class="col-md-18">
                        <div class="form-group">
                          <label>Gender</label>
                          <input type="text" name="std_gender" required>
                        </div>
                      </div>
                      <div class="col-md-18">
                        <div class="form-group">
                          <label>Email</label>
                          <input type="text" name="std_email" required>
                        </div>
                      </div>
                      <div class="col-md-18">
                        <div class="form-group">
                          <label>Phone number</label>
                              <input type="text" name="std_phno" required>
                        </div>
                      </div>
                      <div class="col-md-18">
                        <div class="form-group">
                          <label>Percentage</label>
                          <input type="text" name="std_percentage" required>     
                        </div>
                      </div>
                      <div class="col-md-18">
                        <div class="form-group">
                          <label>Backlogs</label>
                          <input type="text" name="backlogs" required>     
                        </div>
                      </div>
           
                      
                        
                          <button type="submit" class="btn btn-primary">Submit <i
                              class="ft-thumbs-up position-right"></i></button>
                          <button type="reset" class="btn btn-warning">Reset <i
                              class="ft-refresh-cw position-right"></i></button>
                         
                             

</form>
</div>
</div>
       
                                            </div>
                                            <div class="col-lg-6 col-lg-6 mb-2">
                                            <div class="table-responsive">
                                                    <table class="table table-striped table-bordered dataex-visibility-print">
                                                        
                                                        <thead>
                                                                        <tr>
                                                                          <th>Name</th>
                                                                          <th>College Name</th>
                                                                          <th>Branch</th>
                                                                          <th>Regno</th>
                                                                          <th>Sem</th>
                                                                          <th>Gender</th>
                                                                          <th>Email</th>
                                                                          <th>Phone number</th>
                                                                          <th>Percentage</th>
                                                                          <th>Backlogs</th>
                                                                         
                                                                        </tr>
                                                          </thead>
                                                                      <?php
                                                            
                                                                            $sql="SELECT * FROM tbl_std_info where std_clg_name='$college_name' ";
                                                                            $records=mysqli_query($conn,$sql);
                                                                            while($tbl_std_info=mysqli_fetch_array($records))
                                                                            {
                                                                                echo'<tr>';
                                                                                echo'<td>'.$tbl_std_info['std_name'].'</td>';
                                                  
                                                                                echo'<td>'.$tbl_std_info['std_clg_name'].'</td>';
                                                                                echo'<td>'.$tbl_std_info['std_branch'].'</td>';
                                                                                echo'<td>'.$tbl_std_info['std_regno'].'</td>';
                                                                                echo'<td>'.$tbl_std_info['std_sem'].'</td>';
                                                                                echo'<td>'.$tbl_std_info['std_gender'].'</td>';
                                                                                echo'<td>'.$tbl_std_info['std_email'].'</td>';
                                                                                echo'<td>'.$tbl_std_info['std_phno'].'</td>';
                                                                                echo'<td>'.$tbl_std_info['std_percentage'].'</td>';
                                                                                echo'<td>'.$tbl_std_info['backlogs'].'</td>';
                                                                               
                                                                                echo'</tr>';
                                                                    
                                                                                }
                                                                    ?>
                                                            </tfoot>
                                                            </div>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                   
                 
                        
                    </div>
                </section>
                <!-- // card-actions section end -->
            </div>
        </div>
    </div>
    <!-- END: Content-->

  <?php
  include('footer.php');
  ?>

</body>
<!-- END: Body-->

</html>